﻿using System;

namespace $safeprojectname$
{
    public class DemoText
    {
        public DemoText()
        {
            Console.WriteLine("connection string is in create.ps1");
        }
    }
}
