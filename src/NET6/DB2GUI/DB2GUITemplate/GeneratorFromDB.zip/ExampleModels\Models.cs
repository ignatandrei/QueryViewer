﻿namespace $safeprojectname$;
public partial class Models
{

}