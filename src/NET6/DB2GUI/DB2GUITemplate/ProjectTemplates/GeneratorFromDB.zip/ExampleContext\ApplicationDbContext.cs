﻿
using Microsoft.EntityFrameworkCore;

namespace Generated;

public partial class ApplicationDbContext :DbContext
{
    
}
