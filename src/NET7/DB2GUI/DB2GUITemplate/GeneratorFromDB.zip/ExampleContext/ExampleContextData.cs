namespace $safeprojectname$Context;

public class ContextData
{

}
