namespace $safeprojectname$Context;

public class $safeprojectname$ContextData
{

}
