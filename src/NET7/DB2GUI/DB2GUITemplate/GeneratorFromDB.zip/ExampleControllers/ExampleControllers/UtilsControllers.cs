
namespace $safeprojectname$Controllers;

public partial class UtilsControllers   {

    public static List<IRegisterContext> registerContexts = new();


}
