﻿


# NorthwindDBContext

```mermaid
erDiagram
    Alphabetical_list_of_products {
      
      int ProductID 
      
      string ProductName 
      
      int SupplierID 
      
      int CategoryID 
      
      string QuantityPerUnit 
      
      decimal UnitPrice 
      
      short UnitsInStock 
      
      short UnitsOnOrder 
      
      short ReorderLevel 
      
      bool Discontinued 
      
      string CategoryName 
    
    }
    Categories {
      
      int CategoryID 
      
      string CategoryName 
      
      string Description 
      
      byte-Array Picture 
    
    }
    Category_Sales_for_1997 {
      
      string CategoryName 
      
      decimal CategorySales 
    
    }
    Current_Product_List {
      
      int ProductID 
      
      string ProductName 
    
    }
    CustomerDemographics {
      
      string CustomerTypeID 
      
      string CustomerDesc 
    
    }
    Customer_and_Suppliers_by_City {
      
      string City 
      
      string CompanyName 
      
      string ContactName 
      
      string Relationship 
    
    }
    Customers {
      
      string CustomerID 
      
      string CompanyName 
      
      string ContactName 
      
      string ContactTitle 
      
      string Address 
      
      string City 
      
      string Region 
      
      string PostalCode 
      
      string Country 
      
      string Phone 
      
      string Fax 
    
    }
    Customers }o--o{ CustomerDemographics : CustomerCustomerDemo
    Employees {
      
      int EmployeeID 
      
      string LastName 
      
      string FirstName 
      
      string Title 
      
      string TitleOfCourtesy 
      
      DateTime BirthDate 
      
      DateTime HireDate 
      
      string Address 
      
      string City 
      
      string Region 
      
      string PostalCode 
      
      string Country 
      
      string HomePhone 
      
      string Extension 
      
      byte-Array Photo 
      
      string Notes 
      
      int ReportsTo 
      
      string PhotoPath 
    
    }
    Employees }o--o| Employees : FK_Employees_Employees
    Employees }o--o{ Territories : EmployeeTerritories
    Invoices {
      
      string ShipName 
      
      string ShipAddress 
      
      string ShipCity 
      
      string ShipRegion 
      
      string ShipPostalCode 
      
      string ShipCountry 
      
      string CustomerID 
      
      string CustomerName 
      
      string Address 
      
      string City 
      
      string Region 
      
      string PostalCode 
      
      string Country 
      
      string Salesperson 
      
      int OrderID 
      
      DateTime OrderDate 
      
      DateTime RequiredDate 
      
      DateTime ShippedDate 
      
      string ShipperName 
      
      int ProductID 
      
      string ProductName 
      
      decimal UnitPrice 
      
      short Quantity 
      
      float Discount 
      
      decimal ExtendedPrice 
      
      decimal Freight 
    
    }
    Order_Details {
      
      int OrderID 
      
      int ProductID 
      
      decimal UnitPrice 
      
      short Quantity 
      
      float Discount 
    
    }
    Order_Details }o--|| Orders : FK_Order_Details_Orders
    Order_Details }o--|| Products : FK_Order_Details_Products
    Order_Details_Extended {
      
      int OrderID 
      
      int ProductID 
      
      string ProductName 
      
      decimal UnitPrice 
      
      short Quantity 
      
      float Discount 
      
      decimal ExtendedPrice 
    
    }
    Order_Subtotals {
      
      int OrderID 
      
      decimal Subtotal 
    
    }
    Orders {
      
      int OrderID 
      
      string CustomerID 
      
      int EmployeeID 
      
      DateTime OrderDate 
      
      DateTime RequiredDate 
      
      DateTime ShippedDate 
      
      int ShipVia 
      
      decimal Freight 
      
      string ShipName 
      
      string ShipAddress 
      
      string ShipCity 
      
      string ShipRegion 
      
      string ShipPostalCode 
      
      string ShipCountry 
    
    }
    Orders }o--o| Customers : FK_Orders_Customers
    Orders }o--o| Employees : FK_Orders_Employees
    Orders }o--o| Shippers : FK_Orders_Shippers
    Orders_Qry {
      
      int OrderID 
      
      string CustomerID 
      
      int EmployeeID 
      
      DateTime OrderDate 
      
      DateTime RequiredDate 
      
      DateTime ShippedDate 
      
      int ShipVia 
      
      decimal Freight 
      
      string ShipName 
      
      string ShipAddress 
      
      string ShipCity 
      
      string ShipRegion 
      
      string ShipPostalCode 
      
      string ShipCountry 
      
      string CompanyName 
      
      string Address 
      
      string City 
      
      string Region 
      
      string PostalCode 
      
      string Country 
    
    }
    Product_Sales_for_1997 {
      
      string CategoryName 
      
      string ProductName 
      
      decimal ProductSales 
    
    }
    Products {
      
      int ProductID 
      
      string ProductName 
      
      int SupplierID 
      
      int CategoryID 
      
      string QuantityPerUnit 
      
      decimal UnitPrice 
      
      short UnitsInStock 
      
      short UnitsOnOrder 
      
      short ReorderLevel 
      
      bool Discontinued 
    
    }
    Products }o--o| Categories : FK_Products_Categories
    Products }o--o| Suppliers : FK_Products_Suppliers
    Products_Above_Average_Price {
      
      string ProductName 
      
      decimal UnitPrice 
    
    }
    Products_by_Category {
      
      string CategoryName 
      
      string ProductName 
      
      string QuantityPerUnit 
      
      short UnitsInStock 
      
      bool Discontinued 
    
    }
    Quarterly_Orders {
      
      string CustomerID 
      
      string CompanyName 
      
      string City 
      
      string Country 
    
    }
    Region {
      
      int RegionID 
      
      string RegionDescription 
    
    }
    Sales_Totals_by_Amount {
      
      decimal SaleAmount 
      
      int OrderID 
      
      string CompanyName 
      
      DateTime ShippedDate 
    
    }
    Sales_by_Category {
      
      int CategoryID 
      
      string CategoryName 
      
      string ProductName 
      
      decimal ProductSales 
    
    }
    Shippers {
      
      int ShipperID 
      
      string CompanyName 
      
      string Phone 
    
    }
    Summary_of_Sales_by_Quarter {
      
      DateTime ShippedDate 
      
      int OrderID 
      
      decimal Subtotal 
    
    }
    Summary_of_Sales_by_Year {
      
      DateTime ShippedDate 
      
      int OrderID 
      
      decimal Subtotal 
    
    }
    Suppliers {
      
      int SupplierID 
      
      string CompanyName 
      
      string ContactName 
      
      string ContactTitle 
      
      string Address 
      
      string City 
      
      string Region 
      
      string PostalCode 
      
      string Country 
      
      string Phone 
      
      string Fax 
      
      string HomePage 
    
    }
    Territories {
      
      string TerritoryID 
      
      string TerritoryDescription 
      
      int RegionID 
    
    }
    Territories }o--|| Region : FK_Territories_Region
```