﻿


# ApplicationDBContext

```mermaid
erDiagram
    Department {
      
      long IDDepartment 
      
      string Name 
    
    }
    Employee {
      
      long IDEmployee 
      
      string Name 
      
      long IDDepartment 
      
      long Salary 
    
    }
    Employee }o--|| Department : FK_Employee_Department
    test {
      
      int id 
      
      string name 
    
    }
```