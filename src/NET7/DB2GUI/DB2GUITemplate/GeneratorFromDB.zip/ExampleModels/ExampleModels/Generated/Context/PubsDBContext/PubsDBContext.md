﻿


# PubsDBContext

```mermaid
erDiagram
    authors {
      
      string au_id 
      
      string au_lname 
      
      string au_fname 
      
      string phone 
      
      string address 
      
      string city 
      
      string state 
      
      string zip 
      
      bool contract 
    
    }
    discounts {
      
      string discounttype 
      
      string stor_id 
      
      short lowqty 
      
      short highqty 
      
      decimal discount 
    
    }
    discounts }o--o| stores : FK__discounts__stor___74AE54BC
    employee {
      
      string emp_id 
      
      string fname 
      
      string minit 
      
      string lname 
      
      short job_id 
      
      byte job_lvl 
      
      string pub_id 
      
      DateTime hire_date 
    
    }
    employee }o--|| jobs : FK__employee__job_id__01142BA1
    employee }o--|| publishers : FK__employee__pub_id__03F0984C
    jobs {
      
      short job_id 
      
      string job_desc 
      
      byte min_lvl 
      
      byte max_lvl 
    
    }
    pub_info {
      
      string pub_id 
      
      byte-Array logo 
      
      string pr_info 
    
    }
    pub_info |o--|| publishers : FK__pub_info__pub_id__7C4F7684
    publishers {
      
      string pub_id 
      
      string pub_name 
      
      string city 
      
      string state 
      
      string country 
    
    }
    roysched {
      
      string title_id 
      
      int lorange 
      
      int hirange 
      
      int royalty 
    
    }
    roysched }o--|| titles : FK__roysched__title___72C60C4A
    sales {
      
      string stor_id 
      
      string ord_num 
      
      DateTime ord_date 
      
      short qty 
      
      string payterms 
      
      string title_id 
    
    }
    sales }o--|| stores : FK__sales__stor_id__6FE99F9F
    sales }o--|| titles : FK__sales__title_id__70DDC3D8
    stores {
      
      string stor_id 
      
      string stor_name 
      
      string stor_address 
      
      string city 
      
      string state 
      
      string zip 
    
    }
    titleauthor {
      
      string au_id 
      
      string title_id 
      
      byte au_ord 
      
      int royaltyper 
    
    }
    titleauthor }o--|| authors : FK__titleauth__au_id__6A30C649
    titleauthor }o--|| titles : FK__titleauth__title__6B24EA82
    titles {
      
      string title_id 
      
      string title 
      
      string type 
      
      string pub_id 
      
      decimal price 
      
      decimal advance 
      
      int royalty 
      
      int ytd_sales 
      
      string notes 
      
      DateTime pubdate 
    
    }
    titles }o--o| publishers : FK__titles__pub_id__66603565
    titleview {
      
      string title 
      
      byte au_ord 
      
      string au_lname 
      
      decimal price 
      
      int ytd_sales 
      
      string pub_id 
    
    }
```