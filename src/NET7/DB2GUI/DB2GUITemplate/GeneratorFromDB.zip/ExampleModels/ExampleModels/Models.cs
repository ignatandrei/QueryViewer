using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$Models;
[Keyless]
public partial class Models
{

}
