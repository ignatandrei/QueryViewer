import DatabaseAdminGui from "./DatabaseAdminGUI";

export default function ContentAdminGui() {

    return (<>
    <DatabaseAdminGui />
    </>
    )

}