export default class columnTable{
    public name : string='';
    public type: string='';
    public isNullable: boolean=false;
}