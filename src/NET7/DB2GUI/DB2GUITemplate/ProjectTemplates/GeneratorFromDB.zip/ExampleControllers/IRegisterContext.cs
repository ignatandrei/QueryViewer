namespace Generated; 
public interface IRegisterContext
{
    IServiceCollection AddServices(IServiceCollection services, ConfigurationManager configuration);

}
