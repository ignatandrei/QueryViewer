global using $safeprojectname$Blazor;
global using Microsoft.AspNetCore.Components.Web;
global using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
global using Microsoft.Extensions.Configuration;
global using GeneratorFromDB;
global using Microsoft.FluentUI.AspNetCore.Components;
global using System.Net.Http.Json;
global using $safeprojectname$Blazor.Classes;
