global using Microsoft.Extensions.DependencyInjection;
global using Microsoft.IdentityModel.Protocols;
global using System;
global using System.Collections.Generic;
global using Microsoft.Extensions.Configuration;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
global using System;
global using System.Collections.Generic;
global using System.ComponentModel.DataAnnotations;
global using System.ComponentModel.DataAnnotations.Schema;
global using GeneratorFromDB;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.EntityFrameworkCore;
 
