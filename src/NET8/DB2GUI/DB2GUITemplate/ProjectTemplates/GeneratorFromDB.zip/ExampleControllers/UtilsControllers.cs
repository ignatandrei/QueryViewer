namespace Generated;
public partial class UtilsControllers   {

    public static List<IRegisterContext> registerContexts = new();


}
