namespace Generated; 
public interface IRegisterContext
{
    Type AddServices(IServiceCollection services, ConfigurationManager configuration);

}
